---
name: document-generation
category: productivity
description: Generate Word (.docx), PDF, and other office documents programmatically with Python. RTL/Persian support, tables, images, formatting.
triggers:
  - user asks to create a report, document, or file in DOCX/Word/PDF format
  - user needs a structured document with Persian/Arabic text (RTL)
  - user needs bulk document generation from data
---

# Document Generation (python-docx)

## CRITICAL: pip timeout death (this VPS)
- `pip install python-docx` ALWAYS times out on this VPS (>60s network). Do NOT wait for it.
- The `resin-web` venv at `/root/resin-web/venv/bin/python` does NOT have python-docx installed (it failed to install in prior sessions too).
- **DO NOT waste time installing python-docx.** It always fails here.

## Working approaches for DOCX generation (ordered by reliability)

### Approach 1 (MOST RELIABLE): Clone a working file as template
Take the user's OWN working docx file, replace only `word/document.xml` with new content, re-zip:
1. Get a known-working docx from the user (e.g. their v2 file)
2. Unzip it: `unzip -o template.docx -d workdir/`
3. Build new `word/document.xml` with proper XML structure
4. Replace the file: `cp new_document.xml workdir/word/document.xml`
5. Re-zip: `cd workdir && zip -r output.docx .`
6. **Fix `word/theme/theme1.xml`** and `word/styles.xml` to reference B Nazanin font using `sed`
7. Verify all essential files exist in the zip

### Approach 2: Raw XML zip (works for simple cases ONLY)
- Build the entire docx as a ZIP of XML files using `zipfile` + `io.BytesIO`.
- **PROBLEM**: Word OFTEN rejects these as corrupt, even when XML is valid. The structure must exactly match a real Word template — missing metadata, wrong namespace prefixes, or missing `_rels/.rels` all cause "Word experienced an error trying to open the file."
- Use ONLY when the user explicitly says PDF is OK or the document is trivially simple.

### Approach 3: Tool-based conversion (fallback)
- **Pandoc + xelatex**: `pandoc input.docx -o output.pdf --pdf-engine=xelatex -V mainfont="Amiri" -V lang=fa`
- **Prerequisites**: `apt install texlive-xetex texlive-fonts-recommended texlive-lang-arabic`
- **Font limitation**: B Nazanin is NOT installed on this VPS. Use Amiri (installed) as fallback.
- **Known issue**: Unicode arrows (→) fail in Amiri. Result is readable but has glyph warnings.

## What DOES NOT WORK (been there, failed that)
- **`python-docx` from pip**: Always times out. Never got it installed this session.
- **Raw XML with custom namespaces**: Word rejects files with `'Word experienced an error trying to open the file.'` even when all essential XML files are present.
- **Copying document.xml from one docx to another's template**: Only works if the template's styles (Title, Subtitle, Heading1, Compact, etc.) are EXACTLY the styles referenced in document.xml. Document.xml from different versions will have style name mismatches.
- **Building with ET (ElementTree)**: Namespace prefix mangling causes XML corruption.

## When to give up and offer PDF
If 3+ attempts at DOCX generation fail or the user expresses frustration, STOP trying and offer a PDF instead. User's own words: "هرکدوم کار میکنه یه چی میخوام کار کنه" (whatever works, I just want something that works). PDF always opens reliably.

## Raw DOCX construction (zero-dependency fallback)
When python-docx is not available and pip is too slow, create a `.docx` as a ZIP file containing:
```
[Content_Types].xml
_rels/.rels
word/_rels/document.xml.rels
word/document.xml           # the actual content
word/styles.xml              # fonts, heading colors, RTL
word/numbering.xml           # bullet/numbered lists
word/fontTable.xml           # font declarations
word/settings.xml
word/webSettings.xml
word/theme/theme1.xml        # color theme
docProps/core.xml
docProps/app.xml
```

Each is a small XML file. Python stdlib only: `zipfile.ZipFile`, `io.BytesIO`.

### Key RTL setup in document.xml
```xml
<w:sectPr>
  <w:bidi w:val="true"/>
  <w:pgSz w:w="11906" w:h="16838"/>
</w:sectPr>
```

### Key RTL in styles.xml Normal style
```xml
<w:style w:type="paragraph" w:default="1" w:styleId="Normal">
  <w:rPr>
    <w:bidi w:val="true"/>
    <w:rFonts w:ascii="B Nazanin" w:hAnsi="B Nazanin" w:eastAsia="B Nazanin" w:cs="B Nazanin"/>
    <w:sz w:val="22"/>
  </w:rPr>
</w:style>
```

### Bullet list with numbering.xml
Define an abstractNum with bullet format and a num pointing to it. Then in document.xml:
```xml
<w:p>
  <w:pPr>
    <w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>
  </w:pPr>
  <w:r><w:t>text</w:t></w:r>
</w:p>
```

## Design colors for warm Persian reports (for مهبد)
When asked for "beautiful/family-style" colors (not cold blue corporate), use these warm brown-amber tones:

| Element | Hex | Description |
|---------|-----|-------------|
| Title (Heading 1) | `#5D3A1A` | Dark warm brown |
| Subtitle | `#8B7355` | Warm tan/gold |
| Section header (H2) | `#A0522D` | Sienna/warm amber |
| Sub-section (H3) | `#CD853F` | Peru/medium gold |
| Normal text | `#3D2B1F` | Very dark brown |
| Bullet lead text | `#CD853F` | Warm gold accent |
| Background | `#FFFAF0` | Floral white (warm paper) |

Theme name suggestion: `Hermes Warm` — set in theme1.xml for coordinated accent colors.

## RTL / Persian Word Documents

Use `python-docx` library. Key setup for Persian/Arabic (RTL) text:

```python
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

doc = Document()
```

### RTL section setup

```python
sect = doc.sections[0]
sectPr = sect._sectPr
bidi = OxmlElement('w:bidi')
sectPr.append(bidi)
```

### Default font (fallback)

```python
style = doc.styles['Normal']
style.font.name = 'Times New Roman'
style.font.size = Pt(12)
rpr = style.element.get_or_add_rPr()
rfonts = rpr.get_or_add_rFonts()
rfonts.set(qn('w:eastAsia'), 'B Nazanin')
rfonts.set(qn('w:ascii'), 'Times New Roman')
rfonts.set(qn('w:hAnsi'), 'Times New Roman')
```

### RTL paragraph helper

```python
def rtl_para(text='', size=12, bold=False, align='right'):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT if align == 'right' else WD_ALIGN_PARAGRAPH.CENTER
    pPr = p._p.get_or_add_pPr()
    pPr.set(qn('w:bidi'), 'true')
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = 'Times New Roman'
    r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'B Nazanin')
    return p
```

### RTL table helper

```python
def make_table(headers, rows):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.RIGHT
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        p = hdr[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p._p.get_or_add_pPr().set(qn('w:bidi'), 'true')
        run = p.add_run(h)
        run.font.bold = True
        run.font.name = 'Times New Roman'
        run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'B Nazanin')
    for row in rows:
        cells = t.add_row().cells
        for i, val in enumerate(row):
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            p._p.get_or_add_pPr().set(qn('w:bidi'), 'true')
            run = p.add_run(str(val))
            run.font.name = 'Times New Roman'
            run._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), 'B Nazanin')
    return t
```

## Common operations

| Goal | Code |
|---|---|
| Heading | `p = doc.add_paragraph(); r = p.add_run(text); r.font.bold = True; r.font.size = Pt(16)` |
| Bullet point | `p = doc.add_paragraph(style='List Bullet')` + RTL setup |
| Add image | `doc.add_picture(path, width=Inches(5))` |
| Page break | `doc.add_page_break()` |
| Save | `doc.save('/path/to/output.docx')` |

## Reading existing DOCX

```python
import zipfile, re
with zipfile.ZipFile(path) as z:
    xml = z.read('word/document.xml').decode('utf-8')
text = re.sub(r'<[^>]+>', ' ', xml)
text = re.sub(r'\\s+', ' ', text).strip()
```

## Cloning a template's styles (reuse formatting from an existing file)
Extract the `styles.xml` from the user's reference DOCX and repack it with your new `document.xml`:
```python
# Copy styles from template to output:
z_src = zipfile.ZipFile(template_path)
styles_xml = z_src.read('word/styles.xml')
# ... write to new zip with your own document.xml
```
This preserves exact font, color, and heading styling without python-docx.

## Pitfalls

- **B Nazanin not installed**: Falls back to default font. Install via `apt install fonts-bnazanin` or similar.
- **python-docx 1.2.0+**: Older versions lack some API features (e.g. section RTL).
- **Google Fonts blocked in Iran**: Don't rely on CDN fonts for web-exported docs.
- **set_rtl on element**: Use `element.set(qn('w:bidi'), 'true')` — the `'true'` string, not boolean.
- **Table cell scaling**: Cells with long Persian text may not wrap correctly without explicit widths.
- **pip install timeout**: On this VPS, `pip install python-docx` frequently times out (>60s). If it happens once, switch to raw XML zip approach immediately — don't retry.
- **Theme colors in theme1.xml**: When defining a custom color scheme, `document.xml` and `styles.xml` both need to reference the theme colors correctly, or Word falls back to defaults. Test by opening in Word/Online after building.

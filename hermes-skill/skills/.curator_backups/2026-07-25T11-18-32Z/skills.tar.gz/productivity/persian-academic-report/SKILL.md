---
name: persian-academic-report
description: Generate Persian (Farsi) academic/thesis-style reports as editable Word DOCX + PDF from mixed sources (PDFs, DOCX, images) via markdown + pandoc. For Mahbod's university projects (instrumentation, programming, smart parking).
---

# Persian Academic Report Generation

## Trigger
User sends multiple source files (PDF/DOCX/images) and asks for a unified گزارش (report) in Word/PDF format.

## Proven Workflow (pandoc method — RELIABLE)

1. **Extract all source content first:**
   - PDFs: `pdftotext file.pdf -` (NOTE: Persian PDFs often extract reversed/garbled — if text looks like "قرب یسدنهم" it's reversed; rely on readable ones or render pages to PNG with `pdftoppm -png -r 200` and use vision)
   - DOCX: `read_file` auto-extracts text
   - Images (flowcharts): copy from `/root/.hermes/cache/images/` to /tmp with descriptive names

2. **Write single markdown file** in /tmp with:
   - YAML frontmatter (title)
   - Persian headings matching assignment section numbers exactly (بند ۱ الی ۲۱)
   - Pipe tables for comparisons (render as real Word tables)
   - Code blocks for cpp/python/sql
   - Images: `![caption](/tmp/image.jpeg)` — pandoc embeds them into the DOCX

3. **Convert:**
   ```bash
   pandoc report.md -o /var/www/resin-media/name.docx --from markdown
   ```
   - PDF (needs Persian font): `pandoc report.md -o out.pdf --pdf-engine=xelatex -V mainfont='Amiri' -V lang=fa`
   - Amiri is installed on the VPS; B Nazanin is NOT (user applies it in Word later)

4. **Publish:** file in `/var/www/resin-media/` + `chmod 644` (CRITICAL — root-created files 600 give nginx 403), link: `http://u2ssqxd25095.dxdx5.com/media/<name>.docx`

## Pitfalls
- **DO NOT hand-build word/document.xml** (unzip template → replace XML → rezip): produced corrupt files Word refused to open. pandoc md→docx always worked.
- ASCII box-drawing diagrams (┌─┐) in code blocks trigger hundreds of xelatex missing-glyph warnings in PDF; fine in DOCX. Prefer simple text arrows (←/→) for PDF targets.
- Always `chmod 644` after copying to /var/www/resin-media/.
- Check user's structural requirements carefully: e.g. "X must NOT be counted under section Y — put as separate sub-section below" (data architecture, auth, credit system were split out of I/O section into «بخش تکمیلی»).
- Group member names on cover only when requested; user sometimes wants names removed.

## Report conventions (Mahbod)
- University: دانشگاه صنعتی امیرکبیر، دانشکده مهندسی برق
- Professor: دکتر افشار (instrumentation درس ابزار دقیق)
- Group: پارسا بیشه، مهبد بمانی‌چم
- Style: thesis-like, RTL, B Nazanin font (user sets in Word), blue headings preferred
- Instrumentation project spec = 22 numbered بند (process, flowchart, auto/manual modes, operator, safety, I/O, redundancy, disturbances, sensors, signal conditioning circuits, actuators, mitigation, faults, control loop + MATLAB, GUI, Proteus COMPIM data transfer, LCD + Bluetooth, final report)

---  
name: high-voltage-transmission-protocols  
description: Class-level skill for comprehensive reports on high-voltage transmission, substation architecture, IEC protocols, media (RS-232/485/Ethernet/Fiber), HVI panels, marshalling cabinets, RTU inputs, and FEP/HIS/ICCP roles. Includes pitfalls, verification, and references to session-specific details.  
tags: [power-systems, protocols, transmission, substation]  
---  

# Overview  \n- 5‑layer Purdue model applied to HV transmission & substation.  \n- Layers: Field → RTU → FEP → SCADA‑Master/HIS → ERP.  \n- Media: RS‑232, RS‑485, Ethernet, Fiber, PLC, PLCC.  \n- Protocols: IEC 60870‑5‑101/104, IEC 61850 (GOOSE/SV), DNP3, Modbus, OPC UA, ICCP/MMS.  \n\n# Conventional SCADA & TAVANIR Grid Hierarchy (Iran)  \nWhen generating reports or diagrams for the **Iranian Power Grid (TAVANIR)** or conventional RTU-based SCADA:  \n\n### Voltage Chain & Power Flow  \n- **Generation:** Power plant generator (~13.8kV) $\rightarrow$ GSU Transformer (Generator Step-Up, 13.8kV/230kV or 400kV).  \n- **Transmission Grid:** 400kV backbone & 230kV transmission lines.  \n- **Sub-transmission Grid:** 230/63kV (or 400/132kV) substations $\rightarrow$ 63kV (or 132kV) lines.  \n- **Distribution Grid:** 63/20kV substations $\rightarrow$ 20kV urban feeders $\rightarrow$ 20kV/400V distribution transformers.  \n\n### TAVANIR 4-Level SCADA Dispatching Hierarchy  \n1. **SCC (System Control Center - دیسپاچینگ ملی):** Single national center in Tehran (Iran Grid Management Co. / شرکت مدیریت شبکه برق ایران). Handles AGC, frequency regulation, national EMS, inter-regional stability. Receives data from AOCs via **ICCP (TASE.2)** over Fiber WAN.  \n2. **AOC (Area Operating Centers - دیسپاچینگ‌های منطقه‌ای):** 11–12 regional centers across Iran under Regional Electric Companies (شرکت‌های برق منطقه‌ای). Example: **TAOC** (Tehran AOC, most critical). Supervises 400/230/63kV transmission. Uses IEC 104 and ICCP.  \n3. **RDC (Regional Dispatching Centers - دیسپاچینگ فوق توزیع):** Manages ~50–60 substations (63/20kV) per RDC. Handles sub-transmission operations under Regional Electric Co.  \n4. **DAS (Distribution Automation System - اسکادای توزیع):** Under Distribution Companies (شرکت‌های توزیع). Automates 20kV feeders, FRTUs, reclosers, sectionalizers, RMUs, and FLISR (Fault Location, Isolation & Service Restoration).  \n\n### Conventional RTU-Based Signal Path  \n`Switchyard Primary Equipment (CB/DS/CT/VT) -> Control Cables -> HVI Panel -> Marshalling Cabinet -> Transducers (4-20mA) -> RTU AI/DI Cards -> FEP (AOC/RDC) -> SCADA Server -> ICCP -> SCC`  \n\n- **HVI (High Voltage Interface) Panel:** Isolate & convert HV switchyard signals to safe control cabinet levels.  \n- **Marshalling Cabinet:** Central copper terminal wiring hub for cable segregation, testing, and routing.  \n- **Transducers:** Convert 110V / 1A/5A secondary signals to 4-20mA or $\pm$mA for RTU AI cards.  \n- **RTU I/O:** AI (4-20mA MW/MVAr/kV/A), DI (Single/Double point status & alarms), DO (Select-Before-Operate SBO trip/close commands).  \n\n### Conventional Protocol Rationale  \n- **IEC 60870-5-101:** Preferred over low-bandwidth **PLCC** (Power Line Carrier Communication) due to compact ASDU binary frames and Unbalanced polling.  \n- **IEC 60870-5-104:** Migration target over **OPGW** fiber optic ground wire (APCI encapsulation on TCP 2404, spontaneous event reporting).  \n- **ICCP (IEC 60870-6 TASE.2):** Inter-control-center protocol between RDC/AOC and SCC using **Bilateral Tables** to exchange aggregated regional grid states.  \n- **DNP3 & FRTU:** Used on 20kV feeder automation over GPRS/Radio due to robust event buffering during link outages.  \n\n## Diagram Guidelines  \n- Diagrams for Iranian grid MUST show the voltage chain (13.8kV $\rightarrow$ 230kV $\rightarrow$ 63kV $\rightarrow$ 20kV) alongside the dispatching levels (SCC $\rightarrow$ AOC $\rightarrow$ RDC/DAS $\rightarrow$ RTU/Substation).  \n- Always place level headers cleanly at top-left or top-right of bands to avoid text overlapping with inner boxes.  

# Key Protocol Details  
| Protocol | Media | Typical Use | Notes |  
|----------|-------|-------------|-------|  
| IEC 60870‑5‑101 | RS‑232/485 | Legacy SCADA data collection | Heavy binary ASDU, poll‑mode |  
| IEC 60870‑5‑104 | Ethernet (TCP) | Real‑time IED‑to‑SCADA | High‑speed, report‑by‑exception |  
| IEC 61850 | Ethernet | Sub‑station automation | GOOSE (state), SV (sampled values) |  
| DNP3 | RS‑485/TCP | Utility automation | Class‑based priorities, time‑stamped events |  
| Modbus RTU/TCP | RS‑485/Ethernet | Device‑level I/O | Simple register model |  
| OPC UA | Ethernet/VPN | IT‑OT integration | Secure, platform‑agnostic |  
| ICCP/MMS | TCP/IP | Inter‑control‑center messaging | Used by HIS ↔ SCADA‑Master |  

# FEP / HIS / ICCP Roles  
- **FEP** – protocol translation, buffering, security gateway.  
- **HIS** – time‑series archive, analytics, reporting.  
- **ICCP** – state exchange between control centers, redundancy.  

# HVI & Marshalling  
- **HVI panels** collect set‑points, feed RTU.  
- **Marshalling cabinets** isolate and convert analog signals (4‑20 mA) to RTU inputs.  
- **RTU inputs** – analog (4‑20 mA), digital contacts, event (SOE) timestamps.  

# Verification Checklist  
1. Verify correct protocol version per device.  
2. Test redundancy (hot‑standby FEP, SCADA‑Master).  
3. Confirm GOOSE/SV latency < 4 ms.  
4. Check signal conditioning and isolation.  
5. Cross‑check HIS archive vs. RTU SOE logs.  

# Pitfalls  
1. Wrong Modbus address → silent failure.  
2. Missing timestamp in IEC 61850 SV → ordering errors.  
3. FEP buffer overflow → dropped events.  
4. Grounding issues in RS‑485 → CRC errors.  

# Session‑Specific References  
- `references/field-data-collection.md` – HVI panel workflow transcript.  
- `references/protocol-comparison.md` – detailed protocol matrix.  
- `references/fep-verification.sh` – Bash script to verify FEP heartbeat and buffer status.  

# Updates  
- Keep this skill updated with new protocol errata or user style preferences.
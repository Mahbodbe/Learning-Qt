---
name: cron-notifications
description: Send automated notifications from cron jobs to messaging platforms (Telegram, Discord, Slack, etc.) using Hermes' `send` command. Covers fetching external data (APIs), formatting messages, and delivering via configured gateways.
category: productivity
tags:
  - cron
  - notifications
  - telegram
  - discord
  - slack
  - messaging
  - automation
  - api-integration
---

# Cron Notifications Skill

Send automated messages from cron jobs to messaging platforms using Hermes' built-in `send` command. No LLM or agent loop needed — direct gateway delivery.

## When to Use

- Scheduled cron jobs that need to report status, metrics, or alerts
- Price/price-change notifications (crypto, stocks, forex)
- System health checks (disk, memory, service status)
- Deployment/CI completion notifications
- Any recurring automated message delivery

## Prerequisites

1. Hermes configured with at least one messaging platform gateway
2. Platform credentials in `~/.hermes/.env` (bot tokens, chat IDs)
3. `hermes send` command available (built-in)

## Core Workflow

```bash
# 1. Fetch data from external API
curl -s "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd" | jq -r '.bitcoin.usd'

# 2. Format message (supports markdown, emoji)
MESSAGE="₿ Bitcoin: $${BTC_PRICE}"

# 3. Send via Hermes gateway
hermes send --to telegram "$MESSAGE"
# or specific chat: hermes send --to telegram:-1001234567890 "$MESSAGE"
```

## Supported Platforms

| Platform | Target Format | Example |
|----------|---------------|---------|
| Telegram | `telegram` or `telegram:<chat_id>` | `telegram:-1001234567890` |
| Discord | `discord:#channel-name` | `discord:#ops` |
| Slack | `slack:#channel-name` | `slack:#general` |
| Signal | `signal:+15551234567` | `signal:+15551234567` |

List targets: `hermes send --list telegram`

## Message Formatting

- **Markdown**: Telegram/Discord/Slack support basic markdown (`**bold**`, `*italic*`, `` `code` ``, `> quote`)
- **Emoji**: Use directly (💰, ₿, 📈, 🚨, ✅)
- **Newlines**: Preserved in heredoc or `\n` in quoted strings
- **Media**: Prefix with `MEDIA:` — `hermes send --to telegram "MEDIA:/tmp/chart.png"`

## Common Patterns

### Price Alert (Crypto)
```bash
#!/bin/bash
BTC=$(curl -s "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd" | jq -r '.bitcoin.usd')
hermes send --to telegram "₿ **BTC**: \\$${BTC}"
```

### Service Health Check
```bash
#!/bin/bash
if systemctl is-active --quiet nginx; then
    STATUS="✅ nginx running"
else
    STATUS="🚨 nginx DOWN"
fi
hermes send --to telegram "$STATUS"
```

### Timestamp in Iran Time
```bash
TZ=Asia/Tehran date +"%Y/%m/%d %H:%M:%S"
```

### Multi-Source Crypto Price (Session Pattern)
This pattern uses CoinGecko (BTC/XRP) and Wallex (USDT/IRR) to send periodic updates to a Telegram channel. Note: Wallex returns Toman directly (no division needed).

```bash
#!/bin/bash
# File: ~/.hermes/scripts/crypto_prices.sh
set -e
COINGECKO=$(curl -sf "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ripple&vs_currencies=usd" || echo '{}')
WALLEX=$(curl -sf "https://api.wallex.ir/v1/markets" || echo '{}')
NOW=$(TZ=Asia/Tehran date '+%Y-%m-%d %H:%M')
BTC=$(echo "$COINGECKO" | jq -r '.bitcoin.usd // empty')
XRP=$(echo "$COINGECKO" | jq -r '.ripple.usd // empty')
USDT_RAW=$(echo "$WALLEX" | jq -r '.result.symbols.USDTTMN.stats.lastPrice // empty')

MSG="📊 **قیمت‌های لحظه‌ای ارزهای دیجیتال**
⏰ $NOW (وقت ایران)

"
if [ -n "$BTC" ]; then
    BTC_VAL=$(printf "%.2f" "$BTC")
    MSG="${MSG}₿ **Bitcoin (BTC):** \$${BTC_VAL}
"
else
    MSG="${MSG}₿ **Bitcoin (BTC):** خطا
"
fi

if [ -n "$USDT_RAW" ]; then
    USDT_VAL=$(printf "%.0f" "$USDT_RAW")
    MSG="${MSG}💲 **Tether (USDT):** $USDT_VAL تومان
"
else
    MSG="${MSG}💲 **Tether (USDT):** خطا
"
fi

if [ -n "$XRP" ]; then
    XRP_VAL=$(printf "%.4f" "$XRP")
    MSG="${MSG}🔗 **Ripple (XRP):** \$${XRP_VAL}
"
else
    MSG="${MSG}🔗 **Ripple (XRP):** خطا
"
fi

MSG="${MSG}
📈 منبع: CoinGecko & Wallex
🤖 ارسال خودکار هر ۳ ساعت"

echo "$MSG" | hermes send -q --to "telegram:-1004304844769"
```

> ⚠️ **Gotcha**: Never use `$(printf ...)` directly inside a `\"$VAR\"` string that's already inside another `$(...)` or a heredoc — the nested `$()` confuses bash and causes syntax errors. **Always compute formatted values into variables first** (e.g., `BTC_VAL=$(printf "%.2f" "$BTC")`) and then reference the variable.

**Key insights from session:**
- Use `no_agent: true` with a script file for cron jobs that just send data — no LLM needed
- Script must live in `~/.hermes/scripts/` and be executable (`chmod +x`)
- Nobitex returns price in Rial×10 → divide by 10 for Tomans
- `hermes send --to telegram:<chat_id>` targets specific channel/group (negative ID for channels)
- Cron delivery: `deliver: "telegram:<chat_id>"` works but script piping to `hermes send` is more reliable

## Pitfalls & Gotchas

1. **No interactive auth**: `hermes send` uses pre-configured gateway credentials — run `hermes setup` or configure `~/.hermes/.env` first
2. **Chat ID format**: Telegram supergroups/channels use negative IDs (`-100...`), DMs use positive
3. **Rate limits**: Telegram ~30 msg/sec per bot; batch if sending multiple
4. **Markdown escaping**: Underscores, asterisks in data can break formatting — escape or use code blocks
5. **Cron environment**: PATH may be minimal; use full paths (`/usr/local/bin/hermes`) or source profile
6. **Approval prompts**: In some environments, `hermes send` may trigger approval — run interactively once to accept
7. **`hermes send` prints "sent" to stdout** — use `-q` (quiet) flag to suppress when running from cron scripts, otherwise the cron job output log includes unwanted line
8. **Iranian exchange DNS may break**: Nobitex DNS (`api.nobitex.ir`) is unreliable from outside Iran. Wallex (`api.wallex.ir`) works globally and returns Toman directly (no ÷10). Test API reachability before deploying as a cron script

## Verification

```bash
# Test delivery
hermes send --to telegram "Test from cron-notifications skill"

# List configured targets
hermes send --list
```

## References

- `references/telegram-setup.md` — Telegram bot creation and chat ID discovery
- `references/message-formatting.md` — Markdown/emoji guide per platform
- `references/cron-environment.md` — PATH, env vars, logging in cron context
- `references/nobitex-api.md` — Nobitex API (deprecated, DNS unreliable outside Iran)
- `references/wallex-api.md` — Wallex API (preferred, returns Toman directly, works globally)
- `references/crypto-prices-debugging.md` — Debugging session: crypto prices script fixes (GoldAPI, Nginx 403, bot token mismatch)
---
name: django-deployment
description: "Deploy Django projects to production: Gunicorn, Whitenoise, low-RAM setups, Iranian CDN workarounds"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [django, deployment, gunicorn, whitenoise, production, iran, cdn-bypass]
    related_skills: [systematic-debugging, plan]
---

This is a skill the user may invoke when debugging deployment problems. When this user (Mahbod, Persian speaker, ultra-terse preference) asks deployment questions:

- **Communicate in Persian** by default (casual/friendly, NOT formal)
- **Ultra-terse format**: abbreviate, use arrows (→), no filler sentences
- **No markdown tables** — compact inline lists only (user reads on mobile Telegram)
- After delivering a fix: confirm with `✅ fix: [what changed].` and **stop** — do NOT re-explain or continue unless asked
- **Do NOT re-explain what the fix does** after they've seen it work

---

# Django Production Deployment

## When to use
- User asks to deploy a Django project to a production server
- Setting up production-ready Django with admin panel (Unfold/Jazzmin)
- Django needs to work on low-RAM VPS (<1GB) or for Iran-based users (CDN restrictions)

## Communication Style (MANDATORY — see 'persian-speaking-technical-peer' skill)
This skill carries the user's communication preferences in its own SKILL.md.
Load it for full details (ultra-terse, Persian, peer-critic, project separation, etc.).
Key rules applicable here:
- **Persian by default** (casual/friendly, NOT formal)
- **Ultra-terse format**: abbreviate, use → arrows, no filler sentences
- **After fix**: confirm with `✅ fix: [what changed].` and **stop** — do NOT re-explain
- **Never re-explain what the fix does** after they've seen it work

## Steps

### 1. Environment Setup
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Minimum reqs.txt for a typical project:
```
django>=5.0
gunicorn
whitenoise
psycopg2-binary
django-unfold         # if using Unfold admin
python-dotenv         # for .env loading
python-telegram-bot   # if bot attached
celery[redis]         # if background tasks
redis                 # if background tasks
Pillow                # if ImageField used
```

### 2. Settings Production Hardening

**Secrets → `.env`:**
```python
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

SECRET_KEY = os.environ.get("SECRET_KEY")
DEBUG = os.environ.get("DEBUG", "False") == "True"
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "*").split(",")
```

**Static files with Whitenoise** (Django won't serve static in production):
```python
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',  # ← Must be right after Security
    ...
]

STATIC_URL = 'static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
```

Then run: `python manage.py collectstatic --noinput`

**Unfold admin — Iran CDN fix:**
Google Fonts + Material Symbols CDNs are blocked in Iran. The page loads but hangs on font requests. Fix:
```python
UNFOLD = {
    "COLORS": {},        # ← needed to suppress CDN color defaults
    "FONTS": [],         # ← disables Google Fonts CDN fetch
    ...
}
```
After changing UNFOLD config, re-run `collectstatic --clear`.

### 3. Gunicorn — Match Workers to RAM

| RAM  | Workers | Command |
|------|---------|---------|
| 512MB | 1 | `--workers 1` |
| 1GB   | 2 | `--workers 2` |
| 4GB+  | `2*$(nproc)+1` | `--workers $((2 * $(nproc) + 1))` |

```bash
gunicorn website.wsgi:application \
  --bind 0.0.0.0:8000 \
  --workers 1 \
  ### 4. Template Gotcha — No Method Chaining

  Django template engine does NOT allow `.filter(...).first()`.

  **Bad:** `{% with img=p.images.filter(is_primary=True).first %}`  
  `TemplateSyntaxError: Could not parse the remainder: '(is_primary).first'`

  **Bad (model class, no .objects):** `Product.select_related("type")`  
  `AttributeError: Manager isn't available; 'Product' is abstract or is not a model.`  
  This happens when you call `.select_related()` directly on the model class instead of `Product.objects.select_related(...)`.

  **Good — Pre-compute in the view:**
  ```python
  def product_list(request):
      # Always use .objects!
      qs = Product.objects.select_related("type").order_by("-id")
      for p in qs:
          # Pre-compute querysets that you need in templates
          p.primary_image = p.images.filter(is_primary=True).first()
      return render(request, "list.html", {"products": qs})
  ```

### 4.5 Nginx Static File Permissions — 403 Fix

Nginx runs as user `www-data`. If static files live under `/root/something/`, Nginx gets **403 Forbidden**.

**Symptom:** Page loads without CSS. `GET /static/unfold/css/styles.css → 403` in browser dev tools.

**Fix — move to world-readable location:**

```bash
cp -r /path/to/project/staticfiles /var/www/project-static
chown -R www-data:www-data /var/www/project-static
```

Then update Nginx config `location /static/` block to point to the new path, and reload: `nginx -t && systemctl reload nginx`.

### 4.6 Nginx Reverse Proxy (Domain Name)

To put the site on a domain instead of `IP:8000`:

```bash
apt-get install -y nginx
```

Create `/etc/nginx/sites-available/resin`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /static/ {
        alias /var/www/project-static/;
    }

    location /media/ {
        alias /path/to/your/media/;
    }
}
```

Enable:
```bash
ln -sf /etc/nginx/sites-available/resin /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx
```

Now accessible at `http://your-domain.com` (port 80).

### 4.6 Telegram Bot Variable Name — Unify Across Files

The bot file (`store/bot.py`) often has a variable named `Token` that references `settings.TELEGRAM_BOT_TOKEN`. This causes NameError if the variable name drifts. Fix by defining all Telegram env vars at the top of the bot file:

```python
TELEGRAM_BOT_TOKEN = getattr(settings, "TELEGRAM_BOT_TOKEN", "") or ""
TELEGRAM_CHANNEL_CHAT_ID = getattr(settings, "TELEGRAM_CHANNEL_CHAT_ID", "") or ""
TELEGRAM_LOG_CHAT_ID = getattr(settings, "TELEGRAM_LOG_CHAT_ID", "") or ""
```

Then use `TELEGRAM_BOT_TOKEN` everywhere, not `Token`.

### 5. Login Loop Fix
After login, user is redirected back to login page (302 → login again, never reaching dashboard).

**Root cause most of the time:** `DEBUG=False` causes Django to set `CSRF_COOKIE_SECURE` and `SESSION_COOKIE_SECURE` to **True** by default (even if not explicitly set). On plain HTTP (no HTTPS), the browser refuses to attach these secure cookies, so every POST (login form submission) fails CSRF validation silently — the form re-renders without error.

**Fix — explicit secure=False for HTTP:**
```python
CSRF_COOKIE_SECURE = False      # allow CSRF cookie over HTTP
SESSION_COOKIE_SECURE = False   # allow session cookie over HTTP
SESSION_COOKIE_HTTPONLY = True  # prevent JS access (extra hardening)
SESSION_EXPIRE_AT_BROWSER_CLOSE = True  # auto-logout on tab close
```

**Other checks:**
- **Cache**: Clear browser cache + cookies for the domain, or test in **Incognito/Private** window
- **Database sessions**: Run `python manage.py clearsessions` to purge stale session rows
- **Verify superuser**: `echo "from django.contrib.auth import get_user_model; User = get_user_model(); u = User.objects.filter(is_superuser=True).first(); print(f'{u.username} superuser={u.is_superuser}')" | python manage.py shell`
- **Check gunicorn access log**: A `302` on `POST /admin/login/` means login failed. A `200` with login page HTML (12807 bytes typical) means same — form re-rendered. A `302` to `/admin/` means success.

### 5.5 Product Auto-Code Generation — Filter by Type

When a Product model generates codes automatically via `save()`, the naive approach uses a number-range filter that accidentally includes products from other types:

**Bad — range filter:**
```python
max_code = Product.objects.filter(
    code__gte=start, code__lt=start + 10000
).aggregate(m=Max("code"))["m"]
```
If type A starts at 7000 and type B starts at 8000, both fall in the 7000–17000 range, so `max_code` returns 8000 (from type B), causing the new product of type A to get code 8001 instead of 7001.

**Fix — filter by type:**
```python
max_code = Product.objects.filter(type=self.type).aggregate(m=Max("code"))["m"]
self.code = start if max_code is None else max_code + 1
```
This ensures each product type has an independent code sequence.

### 5.6 MEDIA_ROOT Must Match Nginx Alias

Django writes uploads to `MEDIA_ROOT`. Nginx reads from its `location /media/ alias`. If these paths differ, uploads work but images 404 on the storefront.

```python
# settings.py
MEDIA_ROOT = "/var/www/my-media"   # ← must match Nginx alias
```
```nginx
location /media/ { alias /var/www/my-media/; }
```
Then: `chown -R www-data:www-data /var/www/my-media`

### 5.7 Running Celery Tasks Without Redis (Low-RAM Alternative)

If RAM is <1GB, Redis + Celery Worker + Celery Beat can trigger OOM. Replace with a cron job that runs the task directly in the Django context.

Create `/opt/run-promotion.sh`:

```bash
#!/bin/bash
cd /path/to/project/website
source ../venv/bin/activate
python -c "
import django, os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'website.settings')
django.setup()
from store.tasks import process_promotion_queue
process_promotion_queue()
"
```

Then add to user crontab:
```bash
chmod +x /opt/run-promotion.sh
crontab -e
# 0 10 * * * /opt/run-promotion.sh >> /var/log/promotion-cron.log 2>&1
```

This runs the daily promotion post without needing any Celery or Redis processes.

### 6. Firewall
```bash
ufw allow 8000/tcp
```
On cloud panels (Arvan, Hetzner, DigitalOcean), also open the port in the web dashboard.

### 7. Starting Services on Low-RAM
Don't run everything at once — start gunicorn alone first, add others if memory permits:
```bash
# Step 1: Kill leftovers
fuser -k 8000/tcp 2>/dev/null

# Step 2: Start gunicorn
gunicorn website.wsgi:application \
  --bind 0.0.0.0:8000 \
  --workers 1 \
  --timeout 120 \
  --access-logfile /tmp/gunicorn.log &

# Step 3 (if > 768MB free): Redis + Celery
redis-server --daemonize yes
celery -A website worker -l INFO --daemon
celery -A website beat -l WARNING --daemon

# Step 4 (always): Telegram bot
python store/bot.py &
```

### 5.8 Redirects After Login (next parameter)

When using a custom login view, ensure the `next` parameter is preserved from `GET` to `POST`.

**1. View Logic:**
```python
def user_login(request):
    if request.method == 'POST':
        # ... authenticate ...
        if user:
            login(request, user)
            # Check POST first (hidden input), then GET (query string)
            next_url = request.POST.get('next') or request.GET.get('next')
            return redirect(next_url) if next_url else redirect('home')
    return render(request, 'login.html')
```

**2. Template Form:**
Include a hidden input in the login form to carry the `next` value into the `POST` request.
```html
<form method="post">
  {% csrf_token %}
  <input type="hidden" name="next" value="{{ request.GET.next|default:'' }}">
  <!-- ... fields ... -->
</form>
```

**3. JavaScript Redirects:**
When triggering a login redirect from JS (e.g., an AJAX order button), manually append the `next` parameter.
```javascript
function loginAndReturn() {
    const nextPath = window.location.pathname + window.location.search;
    window.location.href = `/login/?next=${encodeURIComponent(nextPath)}`;
}
```

---

## Pitfalls
- **Lost 'next' parameter**: Occurs if the login form `action` URL doesn't include the query string OR if the view only checks `request.GET`. Always check both `POST` and `GET`.
- **405 on order redirect**: If an order endpoint only allows `POST`, a direct redirect (which is `GET`) will fail. Redirect the user back to the product page instead, where they can click the button again.

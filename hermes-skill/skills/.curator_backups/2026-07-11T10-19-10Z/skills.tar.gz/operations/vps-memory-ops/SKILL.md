---
name: vps-memory-ops
description: Memory/swap management and safe service control on the ~961MB-RAM VPS that hosts Mahgol Resin + Hermes. Reusable recipe for swap resize, OOM avoidance, and which services are off-limits.
---

# Low-RAM VPS Memory Operations

## Context
Deployment VPS: ~961 MB RAM, originally a 2 GB `/swapfile`. Co-resident: gunicorn (Mahgol Resin), next-server (9router), hermes-gateway, redis, nginx, x-ui/xray, dockerd. OOM killer periodically kills gunicorn under load.

## Resize swap (reusable recipe)
Swap is a file at `/swapfile`. To grow 2G → 4G (fallocate is faster/cleaner than dd):
```
sudo swapoff /swapfile
sudo fallocate -l 4G /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
free -h
cat /proc/swaps
```
- `mkswap` will warn "wiping old swap signature" — expected.
- To clear swap cache WITHOUT resizing: `sudo swapoff -a && sudo swapon -a`.

## OOM avoidance (durable)
- Keep gunicorn at `--workers 1` (memory-limited; more workers → OOM).
- Grow swap BEFORE raising workers or adding services.
- Watch: `free -m`, `dmesg | grep -i oom`.

## SERVICES YOU MUST NOT KILL (hard constraints)
- **docker** — user: "داکر رو بکشی خودت قطع میشی" (killing docker disconnects your own session). NEVER `systemctl stop docker` / kill dockerd without explicit user OK.
- **9router** (next-server, ~14% RAM, top consumer) — user EXEMPTED it: "هرچی داره زیاد مصرف میکنه رو جز 9router آف کن" means keep 9router, kill the rest. Off-limits.
- **hermes-gateway** — that's this agent. Don't kill yourself.

## Services usually safe to trim — BUT ASK FIRST
snapd, cups, ModemManager, udisks2 are not needed on a headless VPS, yet the user said "اون یکیا هم لازم بوده حتما" (those were needed) — so DO NOT assume; confirm before disabling any.

## Pitfalls
- Don't `fallocate` a swap file while still `swapon`'d without `swapoff` first — mkswap warns and risks corruption.
- Don't kill docker to free RAM — you sever your own session.
- Don't assume a high-RAM process is safe to kill (9router is the biggest but exempt).
